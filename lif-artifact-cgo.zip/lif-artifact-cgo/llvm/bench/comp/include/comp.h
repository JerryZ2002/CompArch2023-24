#ifndef COMP_H
#define COMP_H

#include <stdint.h>

#ifndef _N
#define _N 32
#endif

int32_t comp(int32_t *a, int32_t *b);

#endif
