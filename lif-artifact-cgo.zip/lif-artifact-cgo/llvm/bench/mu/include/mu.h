#ifndef MU_H
#define MU_H

#include <bits/stdint-intn.h>

void mu(int32_t *a);

#endif
