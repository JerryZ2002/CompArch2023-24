// See: https://github.com/oreparaz/dudect/blob/master/inc/random.h
#include <stddef.h>
#include <stdint.h>
void randombytes(uint8_t *x, size_t xlen);
uint8_t randombit(void);
